package helper;

public class Constants {

    public static final String DEEP_LINKING_DESTINATION_ACTION = "com.example.deepLinkingApp2.MainActivity";
    public static final String DEEP_LINKING_DATA_TYPE = "text/plain";

    public static final String PARAMETER1_NAME = "PARAMETER_1";
    public static final String PARAMETER2_NAME = "PARAMETER_2";

}
